# RDPSimplify
C++ implementation of Ramer–Douglas–Peucker algorithm
